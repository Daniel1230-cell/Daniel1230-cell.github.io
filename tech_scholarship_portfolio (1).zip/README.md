# Technology Scholarship Portfolio

This is a simple student technology portfolio website.

## Before submitting
Open `index.html` and replace:
- Your Name
- your.email@example.com

## Publish for free with GitHub Pages
Create a public repository named `YOUR-GITHUB-USERNAME.github.io`, upload `index.html`, then enable GitHub Pages from the repository's Settings > Pages. Your public portfolio will normally be available at:

https://YOUR-GITHUB-USERNAME.github.io/

Official guide: https://docs.github.com/en/pages/quickstart
